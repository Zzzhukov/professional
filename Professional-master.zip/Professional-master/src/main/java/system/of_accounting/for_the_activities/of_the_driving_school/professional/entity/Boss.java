package system.of_accounting.for_the_activities.of_the_driving_school.professional.entity;

public class Boss {
    private Long idBoss;
    private String fullName;
    private String experience;
    private String phone;

    public Long getIdBoss() {
        return idBoss;
    }

    public void setIdBoss(Long idBoss) {
        this.idBoss = idBoss;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
